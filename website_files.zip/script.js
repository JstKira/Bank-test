document.getElementById('startButton').addEventListener('click', function() {
    alert('مرحبًا بك في مملكتي! 🚀');
});
